// mips-assembler.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>
#include "assembly_mapper.h"

using std::string;
using std::cin;
using std::getline;


int main()
{
	assembly_mapper mapper;
	string input;
	while(cin.good())
	{
		getline(cin, input);
		mapper.storeInstruction(input);
		input.clear();
	}
	return 0;
}

