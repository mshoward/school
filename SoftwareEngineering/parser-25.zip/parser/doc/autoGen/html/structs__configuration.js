var structs__configuration =
[
    [ "apache_log_filePath", "structs__configuration.html#a1fa16c2c91316cbaeb6ea3094669d7cf", null ],
    [ "cache_filePath", "structs__configuration.html#a9a1d6b50ac0a873b23a9baa0d86e9d4a", null ],
    [ "honeyd_log_filePath", "structs__configuration.html#a870bc37e7a63c1c619cedaf232230219", null ]
];