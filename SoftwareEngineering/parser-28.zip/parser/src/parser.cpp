#include "parser-includes.hpp"

using namespace parser_sqli;

void main_init()
{
	if (mysql_library_init(0, NULL, NULL)) 
	{
		fprintf(stderr, "could not initialize MySQL library\n");
		std::cout << "could not initialize MySQL library" << std::endl;
		/** exit status 1 means the mysql library couldn't initialize */
		exit(1);
	}
	getConfiguration();
}

void main_exit()
{
	std::cout << "didn't segfault yet " << std::endl;
	mysql_library_end();
}


void safe_NextPopFields(honeyd_parser &someStmt, honeyd_parser::t_LOGTYPE t,
 std::string &someString, std::fstream &someStream)
{
	
	if (!(someStream.eof()))
	{
		std::getline(someStream, someString);
		someStmt.populateFields(someString);
	}
}
void safe_NextPopFields(HoneyDLogStatement &someStmt, std::string &someString, std::fstream &someStream, HoneyDLogStatement::t_LOGTYPE &someType)
{
	
	if (!(someStream.eof()))
	{
		std::getline(someStream, someString);
		someStmt.populateFields(someString, someType);
	}
}



int main()
{
	main_init();
	std::string bucket = "";
	std::fstream cache(configuration.cache_filePath.c_str(), std::ios_base::in);
	std::fstream honey_log(configuration.honeyd_log_filePath.c_str(), std::ios_base::in);
	//std::fstream apache_log(configuration.apache_log_filePath.c_str(), std::ios_base::in);
	
	HoneyDLogStatement coolGuyJones;
	honeyd_parser myParser;
	unsigned long int lineNo = 0;
	unsigned long int last = 0;
	unsigned long int totalNo = 18762;
	mysqlPush mysql
	(
		"honeypot1.db.7456864.hostedresource.com",
		"honeypot1",
		"Honeypot1#",
		"honeypot1",
		3306,
		NULL,
		0,
		&cache
	);
	
	flushCache(cache, mysql);
	cache.close();
	dumpFile(configuration.cache_filePath);
	cache.open(configuration.cache_filePath.c_str(), std::ios_base::out);
	std::cout << "IT'S WORKING: " << mysql.isConnected() << std::endl;
	std::cout << last << " %" << std::endl;
	while (!(honey_log.eof()))
	{
		lineNo++;
		if (((lineNo * 100) / totalNo) != last)
		{
			last = ((lineNo * 100) / totalNo);
			std::cout << last << " %" << std::endl;
		}
		safe_NextPopFields(coolGuyJones, bucket, honey_log);
		mysql.update(&coolGuyJones);
	}
	honey_log.close();
	dumpFile(configuration.honeyd_log_filePath);
	
	/*while (!(apache_log.eof()))
	{
		safe_NextPopFields(coolGuyJones, bucket, apache_log);
		mysql.update(&coolGuyJones);
	}
	apache_log.close();
	dumpFile(configuration.apache_log_filePath);
	*/
	std::cout << "IT'S WORKING: " << mysql.isConnected() << std::endl;
	
	std::cout << std::endl;
	mysql.close();
	std::cout << "closed successfully?" << std::endl;
	mysql.clean();
	std::cout << "cleaned successfully?" << std::endl;
	main_exit();
	std::cout << "exited successfully?" << std::endl;
	std::cout << "DONE" << std::endl;
	/** exit status zero means everything is ok */
return 0;
}
