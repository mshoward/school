
//sets empty strings and isGood to false
hdparser::honeyd_parser::honeyd_parser()
{
	currString = "";
	timeStamp = "";
	packetType = "";
	sourceIP = "";
	sourceSocket = "";
	targetIP = "";
	targetSocket = "";
	osVersion = "";
	isGood = false;
	index = 0;
}

//nothing to free
hdparser::honeyd_parser::~honeyd_parser()
{
	
}

//sets fields
hdparser::honeyd_parser::honeyd_parser(std::string rawString)
{
	setString(rawString);
}

//sets fields
void hdparser::honeyd_parser::setString(std::string rawString)
{
	std::stringstream input(rawString, std::ios_base::in);
	currString = rawString;
	std::getline(input, timeStamp, ' ');
	std::getline(input, packetType, ' ');
	std::getline(input, sourceIP, ' ');
	std::getline(input, sourceSocket, ' ');
	std::getline(input, targetIP, ' ');
	std::getline(input, targetSocket, ' ');
	std::getline(input, targetSocket, ' ');
	std::getline(input, osVersion); /*
	the end of the log after this gets messy
	and I don't really understand it, so I'll shove it on the
	beginning of osVersion*/
	isGood = true;
	index = 0;
}

hdparser::honeyd_parser::honeyd_parser(std::string rawString, t_LOGTYPE setting)
{
	mode = setting;
	setString(rawString);
}

//returns the timestamp or a string saying 
//the parser's not been given a string
std::string hdparser::honeyd_parser::getTimeStamp()
{
	if(isGood)
		return timeStamp;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}

//same as above
std::string hdparser::honeyd_parser::getPacketType()
{
	if(isGood)
		return packetType;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}

std::string hdparser::honeyd_parser::getSourceIP()
{
	if(isGood)
		return sourceIP;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}
std::string hdparser::honeyd_parser::getTargetIP()
{
	if(isGood)
		return targetIP;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}
std::string hdparser::honeyd_parser::getSourceSocket()
{
	if(isGood)
		return sourceSocket;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}
std::string hdparser::honeyd_parser::getTargetSocket()
{
	if(isGood)
		return targetSocket;
	else
	{
		std::string ret;
		ret = "I HAVE NOT BEEN GIVEN A STRING";
		return ret;
	}
}

std::string hdparser::honeyd_parser::getOsVersion()
{
	if(isGood)
		return osVersion;
	else
	{
		std::string ret;
		ret = "INVALID";
		return ret;
	}
}

bool hdparser::honeyd_parser::isGNumber(char c)
{
	return ((c == '0') || (c == '1') ||
			(c == '2') ||
			(c == '3') ||
			(c == '4') ||
			(c == '5') ||
			(c == '6') ||
			(c == '7') ||
			(c == '8') ||
			(c == '9') );
}

bool hdparser::honeyd_parser::isGAlpha(char c)
{
	return ((c == 'a') || (c == 'A') ||
			(c == 'b') || (c == 'B') ||
			(c == 'c') || (c == 'C') ||
			(c == 'd') || (c == 'D') ||
			(c == 'e') || (c == 'E') ||
			(c == 'f') || (c == 'F') ||
			(c == 'g') || (c == 'G') ||
			(c == 'h') || (c == 'H') ||
			(c == 'i') || (c == 'I') ||
			(c == 'j') || (c == 'J') ||
			(c == 'k') || (c == 'K') ||
			(c == 'l') || (c == 'L') ||
			(c == 'm') || (c == 'M') ||
			(c == 'n') || (c == 'N') ||
			(c == 'o') || (c == 'O') ||
			(c == 'p') || (c == 'P') ||
			(c == 'q') || (c == 'Q') ||
			(c == 'r') || (c == 'R') ||
			(c == 's') || (c == 'S') ||
			(c == 't') || (c == 'T') ||
			(c == 'u') || (c == 'U') ||
			(c == 'v') || (c == 'V') ||
			(c == 'x') || (c == 'X') ||
			(c == 'y') || (c == 'Y') ||
			(c == 'z') || (c == 'Z') );
}

bool hdparser::honeyd_parser::isSymbol(char c, char symbol)
{
	return (c == symbol);
}

bool hdparser::honeyd_parser::isTimeStamp(std::string s)
{
	//2014-02-02-17:54:29.3535
	//0123456789 11131517192123
	//          10121416182022
	int ptr = 0;
	bool ret = true;
	while (ptr < s.length() && ret)
	{
		if (ptr < 4)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 5)
		{
			ret = ret && isSymbol(s[ptr], '-');
		}
		else if (ptr < 7)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 8)
		{
			ret = ret && isSymbol(s[ptr], '-');
		}
		else if (ptr < 10)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 11)
		{
			ret = ret && isSymbol(s[ptr], '-');
		}
		//2014-02-02-17:54:29.3535
		//0123456789 11131517192123
		//          10121416182022
		else if (ptr < 13)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 14)
		{
			ret = ret && isSymbol(s[ptr], ':');
		}
		else if (ptr < 16)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 17)
		{
			ret = ret && isSymbol(s[ptr], ':');
		}
		else if (ptr < 19)
		{
			ret = ret && isGNumber(s[ptr]);
		}
		else if (ptr < 20)
		{
			ret = ret && isSymbol(s[ptr], '.');
		}
		//2014-02-02-17:54:29.3535
		//0123456789 11131517192123
		//          10121416182022
		else if (ptr < s.length())
		{
			ret = ret && (isGNumber(s[ptr]) || isSymbol(s[ptr], (char) 32) || isSymbol(s[ptr], (char) 9) || isSymbol(s[ptr], (char) 0));
		}
		ptr++;
	}
	return ret;
}
bool hdparser::honeyd_parser::isPacketType(std::string s)
{
	bool ret = true;
	for(int i = 0; (i < s.length()) && ret; i++)
	{
		if (isGAlpha(s[i]) || isSymbol(s[i], (char) 0))
		{
			ret = ret && true;
		}
		else
		{
			if (isSymbol(s[i], '('))
			{
				i++;
				bool cont = true;
				for(;((i < s.length()) && ret) && cont; i++)
				{
					//std::cout << "REJECTING BECAUSE " << s[i] << " isn't a (" << std::endl;
					ret = ret && (isGNumber(s[i]) || isSymbol(s[i], ')'));
					if (isSymbol(s[i], ')'))
						cont = false;
				}
			}
			else
			{
				//std::cout << "REJECTING BECAUSE " << s[i] << "isn't a (" << std::endl;
				ret = ret && false;
			}
		}
	}
	//std::cout << "END OF CALL " << std::endl;
	return ret;
}
bool hdparser::honeyd_parser::isIP(std::string s)
{
	bool ret = true;
	int temp = 0;
	for(int i = 0; (i < s.length()) && ret; i++)
	{
		if (temp == 3)
		{
			ret = ret && (isSymbol(s[i], '.') || isSymbol(s[i], ' ') || isSymbol(s[i], (char) 0));
			if (isSymbol(s[i], '.'))
				temp = 0;
		}
		if (isGNumber(s[i]))
			temp++;
		
	}
}
bool hdparser::honeyd_parser::isSocket(std::string s)
{
	bool ret = true;
	for(int i = 0; i < s.length(); i++)
	{
		ret = ret && (isGNumber(s[i]) || isSymbol(s[i], ':') || isSymbol(s[i], (char) 0) || isSymbol(s[i], ' '));
	}
	return ret;
}

bool hdparser::honeyd_parser::isOSVersion(std::string s)
{
	return true;
}


bool hdparser::honeyd_parser::getValidTimeStamp()
{
	//2014-02-02-17:54:29.3535
	return isTimeStamp(timeStamp);
}

bool hdparser::honeyd_parser::getValidPacketType()
{
	return isPacketType(packetType);
}

bool hdparser::honeyd_parser::getValidSourceIP()
{
	return isIP(sourceIP);
}

bool hdparser::honeyd_parser::getValidTargetIP()
{
	return isIP(targetIP);
}

bool hdparser::honeyd_parser::getValidTargetSocket()
{
	return isSocket(targetSocket);
}

bool hdparser::honeyd_parser::getValidOsVersion()
{
	return isOSVersion(osVersion);
}
