#include "include/mysqlPush.hpp"

mysqlPush::mysqlPush()
{
	//don't use
	mode = OTHER;
	backup = NULL;
	mysql = NULL;
	stmt = NULL;
	query = "";
	
}

mysqlPush::mysqlPush(const char *host, const char *user, const char *passwd,
			const char *db, unsigned int port, const char *unix_socket,
			unsigned long client_flag)
{
	my_init();
	mysql = mysql_init(NULL);
	MYSQL *mysql_real_connect(mysql, host, user, passwd, db, port, unix_socket, client_flag);
	
	
}
