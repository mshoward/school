#include "mysql.h"

class mysqlPush
{
	private:
	enum MODE {TO_SERVER, TO_FILE, OTHER};
	
	MODE mode;
	fstream *backup;
	MYSQL *mysql;
	MYSQL_STMT *stmt;
	string query;
	
	
	public:
	mysqlPush();
	mysqlPush(const char *host, const char *user, const char *passwd,
			const char *db, unsigned int port, const char *unix_socket,
			unsigned long client_flag);
	~mysqlPush();
	
	
	
	
	
	int updateServer(HoneyDLogStatement *params);
	int updateFile(HoneyDLogStatement *params);
	bool isGood();
	bool clean();
	//MYSQL *mysql_real_connect(MYSQL *mysql, const char *host, const char *user, const char *passwd,
	// const char *db, unsigned int port, const char *unix_socket, unsigned long client_flag)
};
