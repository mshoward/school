var parser_sqli_8hpp =
[
    [ "SQLI_LIST", "parser-sqli_8hpp.html#a61eecc6bde4b2f31ce438f9366250575", null ],
    [ "SQLI_LIST_LENGTH", "parser-sqli_8hpp.html#abbb416f7bc090b4aa7d229c66b79116e", null ]
];