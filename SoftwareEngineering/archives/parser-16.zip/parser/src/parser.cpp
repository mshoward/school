#include "parser-includes.hpp"

using namespace parser_sqli;
//demo
int main()
{
	std::string buf;
	int n;
	//std::cout << "hello world" << std::endl;
	/*for (int i = 0; i < SQLI_LIST_LENGTH; i++)
	{
		std::cout << SQLI_LIST[i] << std::endl;
	}
	*/
	std::fstream f1("samples/logfile.txt", std::ios::in);
	HoneyDLogStatement stmt;
	hdparser::honeyd_parser par;
	int counter = 0;
	while (!(f1.eof()))
	{
		std::getline(f1, buf);
		stmt.populateFields(buf);
		par.setString(buf);
		std::cout << std::endl << "Entry Number: " << counter << std::endl;
		std::cout << "ts:" << stmt.timeStamp << std::endl;
		//std::cout << "TSBool: " << par.isTimeStamp(stmt.timeStamp) << std::endl;
		//std::cout << "pt:" << stmt.packetType << std::endl;
		//std::cout << "PTBool: " << par.isPacketType(stmt.packetType) << std::endl;
		//std::cout << "sip:" << stmt.sourceIP << std::endl;
		//std::cout << "IPBool: " << par.isIP(stmt.sourceIP) << std::endl;
		//std::cout << "ss:" << stmt.sourceSocket << std::endl;
		//std::cout << "SBool: " << par.isSocket(stmt.sourceSocket) << std::endl;
		//std::cout << "tip:" << stmt.targetIP << std::endl;
		//std::cout << "IPBool: " << par.isIP(stmt.targetIP) << std::endl;
		//std::cout << "ts: " << stmt.targetSocket << std::endl;
		//std::cout << "SBool: " << par.isSocket(stmt.targetSocket) << std::endl;
		//std::cout << "osv:" << stmt.osVersion << std::endl;
		//std::cout << counter << std::endl;
		counter++;
		//std::cin >> n;
	}
	
	f1.close();
	std::cout << "DONE" << std::endl;
	std::cout << std::endl;
return 0;
}
