#!/bin/bash
g++ parser.cpp -o Parser
