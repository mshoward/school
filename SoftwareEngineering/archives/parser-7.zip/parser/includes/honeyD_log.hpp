#ifndef HD_LOG_STATEMENT_H
#define HD_LOG_STATEMENT_H
/* wrapper for the honeyd_parser so the parser can be improved at will
 * without messing up the interface */
	class HoneyDLogStatement
	{
		public:
		
			std::string timeStamp; //DateTime
			std::string packetType; //packetType
			std::string sourceIP; //sourceIP -000.000.000.000
			std::string sourceSocket; //sourceSocket
			std::string targetIP; //targetIP
			std::string targetSocket;//targetSocket
			std::string osVersion; //Version
			HoneyDLogStatement();
			~HoneyDLogStatement();
			HoneyDLogStatement(std::string rawLine);
			void populateFields(std::string rawLine);
	};
#endif
