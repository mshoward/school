var searchData=
[
  ['osversion',['OSVERSION',['../classhdparser_1_1honeyd__parser.html#a9130c41ad6b64e129940e021b61bdc4da751d0952ba1c68480f489610237f4198',1,'hdparser::honeyd_parser']]]
];
