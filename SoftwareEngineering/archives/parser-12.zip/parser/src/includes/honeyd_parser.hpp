#ifndef HONEYD_PARSER_HEADER
#define HONEYD_PARSER_HEADER
namespace hdparser
{
	/* parser backend */
	class honeyd_parser
	{
		private:
		bool isGNumber(char c);
		bool isGAlpha(char c);
		bool isSymbol(char c, char symbol);
		bool isTimeStamp(std::string s);
		bool isPacketType(std::string s);
		bool isIP(std::string s);
		bool isSocket(std::string s);
		bool isOSVersion(std::string s);
		
		public:
			
			std::string currString;
			std::string timeStamp;
			std::string packetType;
			std::string sourceIP;
			std::string sourceSocket;
			std::string targetIP;
			std::string targetSocket;
			std::string osVersion;
			int index;
			bool isGood;
			enum t_LOGTYPE {HONEY_D, OTHER_LOG} mode;
			enum WORDTYPE
			{
				TIMESTAMP,
				PACKETTYPE,
				SOURCEIP,
				SOURCESOCKET,
				TARGETIP,
				TARGETSOCKET,
				OSVERSION
			};
			//TODO:: implement a smarter parser

			honeyd_parser();//done
			honeyd_parser(std::string rawString);//done
			honeyd_parser(std::string rawString, t_LOGTYPE setting);
			~honeyd_parser();//nothing to do, so done by default
			void setString(std::string rawString);//done
			std::string getTimeStamp();//done
			bool getValidTimeStamp();
			
			std::string getPacketType();//done
			bool getValidPacketType();
			
			std::string getSourceIP();//done
			bool getValidSourceIP();
			
			std::string getTargetIP();//done
			bool getValidTargetIP();
			
			std::string getTargetSocket();//done
			bool getValidTargetSocket();
			
			std::string getOsVersion();//done
			bool getValidOsVersion();
	};
}
#endif
