//#include "include/mysqlPush.hpp"


/**
 * don't use -- is trash and pointless to have
 * if you accidentally use it, deallocate immediately and call the other constructor
 */
mysqlPush::mysqlPush()
{
	//don't use
	mode = OTHER;
	backup = NULL;
	mysql = NULL;
	stmt = NULL;
	query = "";
	
}



/**
 * starts the mysql server connection
 * sets up all the things
 * inits the prepared sql statements
 * sets output mode
 * is magic
 */
mysqlPush::mysqlPush(const char *host, const char *user, const char *passwd,
			const char *db, unsigned int port, const char *unix_socket,
			unsigned long client_flag, std::fstream *backUpFileStream)
{
	
	//init mysql stuff
	my_init();
	mysql = mysql_init(NULL);
	mysql = mysql_real_connect(mysql, host, user, passwd, db, port, unix_socket, client_flag);
	backup = backUpFileStream;
	query = "INSERT INTO Information (DateTime, packetType, sourceIP, sourceSocket, targetIP, targetSocket, Version) VALUES (?, ?, ?, ?, ?, ?, ?)";
	query2 = "THIS IS NOT THE OTHER QUERY";
	if (mysql_ping(mysql) != 0)
		if (backup->is_open())
			mode = TO_FILE;
		else
			mode = OTHER;
	else
		mode = TO_SERVER;
	stmt = mysql_stmt_init(mysql);
	binds = 0;
	stmt2 = mysql_stmt_init(mysql);
	mysql_stmt_prepare(stmt, query.c_str(), query.length());
	mysql_stmt_prepare(stmt2, query2.c_str(), query2.length());
}


/** Will determine the correct function to call based on current state
 */
int mysqlPush::update(HoneyDLogStatement *params)
{
	int ret = 1;
	isConnected();
	if (mode == TO_SERVER)
		ret = updateServer(params);
	
	if ((ret != 0) && (mode != OTHER))
		return updateFile(params);
	if (mode == OTHER)
		return 1;
}

void mysqlPush::prepStmt(HoneyDLogStatement *params)
{
	if (binds != (MYSQL_BIND *) 0)
	{
		free(binds);
		binds = 0;
	}
	binds = (MYSQL_BIND *) malloc(sizeof(MYSQL_BIND) * 7);
	memset(binds, 0, sizeof(binds));
	
	binds[0].buffer_type = MYSQL_TYPE_STRING;
	binds[0].buffer = &(params->timeStamp[0]);
	binds[0].buffer_length = params->timeStamp.length();
	*(binds[0].length) = (params->timeStamp.length());
	binds[0].is_null = (my_bool *) 0;
	
	/**
	 * finish the rest of them
	 */
	binds[1].buffer_type = MYSQL_TYPE_STRING;
	binds[1].buffer = &(params->packetType[0]);
	binds[1].buffer_length = params->packetType.length();
	*(binds[1].length) = (params->packetType.length());
	binds[1].is_null = (my_bool *) 0;
	
	binds[2].buffer_type = MYSQL_TYPE_STRING;
	binds[2].buffer = &(params->sourceIP[0]);
	binds[2].buffer_length = params->sourceIP.length();
	*(binds[2].length) = (params->sourceIP.length());
	binds[2].is_null = (my_bool *) 0;
	
	binds[3].buffer_type = MYSQL_TYPE_STRING;
	binds[3].buffer = &(params->sourceSocket[0]);
	binds[3].buffer_length = params->sourceSocket.length();
	*(binds[3].length) = (params->sourceSocket.length());
	binds[3].is_null = (my_bool *) 0;
	
	binds[4].buffer_type = MYSQL_TYPE_STRING;
	binds[4].buffer = &(params->targetIP[0]);
	binds[4].buffer_length = params->targetIP.length();
	*(binds[4].length) = (params->targetIP.length());
	binds[4].is_null = (my_bool *) 0;
	
	binds[5].buffer_type = MYSQL_TYPE_STRING;
	binds[5].buffer = &(params->targetSocket[0]);
	binds[5].buffer_length = params->targetSocket.length();
	*(binds[5].length) = (params->targetSocket.length());
	binds[5].is_null = (my_bool *) 0;
	
	binds[6].buffer_type = MYSQL_TYPE_STRING;
	binds[6].buffer = &(params->osVersion[0]);
	binds[6].buffer_length = params->osVersion.length();
	*(binds[6].length) = (params->osVersion.length());
	binds[6].is_null = (my_bool *) 0;binds[0].buffer_type = MYSQL_TYPE_STRING;
	
	mysql_stmt_bind_param(stmt, binds);
}


int mysqlPush::updateServer(HoneyDLogStatement *params)
{
	//(DateTime, packetType, sourceIP, sourceSocket, targetIP, targetSocket, Version)
	prepStmt(params);
	
	if (isConnected())
	{
		mysql_stmt_bind_param(stmt, binds);
		
		mysql_stmt_execute(stmt);
		return 0;
	}
	else
		return 1;
	
}

bool mysqlPush::isConnected()
{
	if (mysql_ping(mysql) != 0)
	{
		if (backup->is_open())
		{
			mode = TO_FILE;
			return false;
		}
		else
		{
			mode = OTHER;
			return false;
		}
	}
	else
	{
		mode = TO_SERVER;
		return true;
	}
}

/**
 * need to check for whether or not stream is good to go before shoving things at it
 */
int mysqlPush::updateFile(HoneyDLogStatement *params)
{
	
	(*backup) << "INSERT INTO Information (DateTime, packetType, sourceIP, sourceSocket, targetIP, targetSocket, Version) VALUES (";
	(*backup) << params->timeStamp << ", " << params->packetType << ", " << params->sourceIP << ", ";
	(*backup) << params->sourceSocket << ", " << params->targetIP << ", " << params->targetSocket << ", " << params->osVersion << ");" << std::endl;
	return 0;
}

bool mysqlPush::clean()
{
	if (binds != (MYSQL_BIND *) 0)
	{
		free(binds);
		binds = 0;
	}
	return true;
}
