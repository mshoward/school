INSERT INTO Information (DateTime, packetType, sourceIP, sourceSocket, targetIP, targetSocket, Version) VALUES 	(?, ?, ?, ?, ?, ?, ?)
