#pragma once
/* I dont currently have anything that's needed here */

#DEFINE PATH "./conf/lpmc.conf"
typedef struct
{
	std::string honeyd_log_filePath;
	std::string apache_log_filePath;
	std::string cache_filePath;
	std::string * otherFiles; 
} s_configuration;

s_configuration configuration;


std::string nextUsefulLine(std::fstream &str, std::string &s)
{
	getline(str, s);
	while(s[0] == '#')
	{
		getline(str, s);
	}
}

void getConfiguration()
{
	std::fstream conf(PATH, ios_base::in);
	std::string ln = "";
	
	if (!(conf.is_open()))
	{
		fprintf(stderr, "Config file not found.  Exiting lpmc.");
		printf("Config file not found.  Exiting lpmc.");
		exit(2);
	}
	std::getline(conf, ln);
	
	
}
