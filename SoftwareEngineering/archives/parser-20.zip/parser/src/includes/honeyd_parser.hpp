#pragma once
namespace hdparser
{
	/* parser backend */
	/** Someone implementing a log parser should never
	 * have to touch this.  The log statement is desigend
	 * around not having to touch this class.  Also, the
	 * searching it does to detect attacks is case insensitive.
	 * */
	 
	class honeyd_parser
	{
		private:
		
		
		public:
			/** internal */
			bool isGNumber(char c);
			/** internal */
			bool isGAlpha(char c);
			/** internal */
			bool isSymbol(char c, char symbol);
			/** internal */
			bool isTimeStamp(std::string s);
			/** internal */
			bool isPacketType(std::string s);
			/** internal */
			bool isIP(std::string s);
			/** internal */
			bool isSocket(std::string s);
			/** internal */
			bool isOSVersion(std::string s);
			
			/** raw, unfiltered data */
			std::string currString;
			/** raw, unfiltered data */
			std::string timeStamp;
			/** raw, unfiltered data */
			std::string packetType;
			/** raw, unfiltered data */
			std::string sourceIP;
			/** raw, unfiltered data */
			std::string sourceSocket;
			/** raw, unfiltered data */
			std::string targetIP;
			/** raw, unfiltered data */
			std::string targetSocket;
			/** raw, unfiltered data */
			std::string osVersion;
			/** bucket for extra data from apache logs */
			std::string junkData;
			
			/** unused, currently */
			int index;
			/** internal */
			bool isGood;
			/** this is / will be set in the constructor */
			enum t_LOGTYPE {HONEY_D, OTHER_LOG, APACHE} mode;
			/** internal */
			enum t_ATTACK_TYPE {SQL_INJECTION, XSS, DUBIOUS_PHP, HTTP_ETC};
			
			/** internal -- to be used in implementing a more dynamic parser */
			enum WORDTYPE
			{
				TIMESTAMP,
				PACKETTYPE,
				SOURCEIP,
				SOURCESOCKET,
				TARGETIP,
				TARGETSOCKET,
				OSVERSION
			};
			//TODO:: implement a smarter parser

			honeyd_parser();//done
			/** basic constructor, assumes honeyd log */
			honeyd_parser(std::string rawString);//done
			/** more explicit constructor, once it's improved */
			honeyd_parser(std::string rawString, t_LOGTYPE setting);
			~honeyd_parser();//nothing to do, so done by default
			
			/** called by honeyd_log_statement */
			void setString(std::string rawString);//done
			
			std::string getTimeStamp();//done
			bool getValidTimeStamp();
			
			std::string getPacketType();//done
			bool getValidPacketType();
			
			std::string getSourceIP();//done
			bool getValidSourceIP();
			
			std::string getSourceSocket();
			bool getValidSourceSocket();
			
			std::string getTargetIP();//done
			bool getValidTargetIP();
			
			std::string getTargetSocket();//done
			bool getValidTargetSocket();
			
			std::string getOsVersion();//done
			bool getValidOsVersion();
			
			std::string getJunkData();
			t_ATTACK_TYPE getJunkDataAttackType();
			std::string toUpper(std::string strToBeUpper);
			
	};
}
