//#include "mysql.h"

class mysqlPush
{
	private:
	enum MODE {TO_SERVER, TO_FILE, OTHER};
	
	MODE mode;
	std::fstream *backup;
	MYSQL *mysql;
	MYSQL_STMT *stmt;
	MYSQL_STMT *stmt2;
	std::string query;
	std::string query2;
	std::string dumpToFile;
	std::string dumpToFile2;
	
	
	public:
	mysqlPush();
	mysqlPush(const char *host, const char *user, const char *passwd,
			const char *db, unsigned int port, const char *unix_socket,
			unsigned long client_flag, std::fstream *backUpFileStream);
	~mysqlPush();
	
	
	
	
	int update(HoneyDLogStatement *params);
	int updateServer(HoneyDLogStatement *params);
	int updateFile(HoneyDLogStatement *params);
	bool isGood();
	bool clean();
	//MYSQL *mysql_real_connect(MYSQL *mysql, const char *host, const char *user, const char *passwd,
	// const char *db, unsigned int port, const char *unix_socket, unsigned long client_flag)
};
