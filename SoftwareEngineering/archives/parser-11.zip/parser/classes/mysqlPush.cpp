//#include "include/mysqlPush.hpp"

mysqlPush::mysqlPush()
{
	//don't use
	mode = OTHER;
	backup = NULL;
	mysql = NULL;
	stmt = NULL;
	query = "";
	
}

mysqlPush::mysqlPush(const char *host, const char *user, const char *passwd,
			const char *db, unsigned int port, const char *unix_socket,
			unsigned long client_flag, std::fstream *backUpFileStream)
{
	
	//init mysql stuff
	my_init();
	mysql = mysql_init(NULL);
	mysql = mysql_real_connect(mysql, host, user, passwd, db, port, unix_socket, client_flag);
	backup = backUpFileStream;
	query = "THIS IS NOT THE QUERY";
	query2 = "THIS IS NOT THE OTHER QUERY";
	if (mysql_ping(mysql) != 0)
		if (backup->is_open())
			mode = TO_FILE;
		else
			mode = OTHER;
	else
		mode = TO_SERVER;
	stmt = mysql_stmt_init(mysql);
	stmt2 = mysql_stmt_init(mysql);
	mysql_stmt_prepare(stmt, query.c_str(), query.length());
	mysql_stmt_prepare(stmt2, query2.c_str(), query2.length());
	
}

int mysqlPush::update(HoneyDLogStatement *params)
{
	if (mode == TO_SERVER)
		return updateServer(params);
	if (mode == TO_FILE)
		return updateFile(params);
	if (mode == OTHER)
		return 1;
}

int mysqlPush::updateFile(HoneyDLogStatement *params)
{
	
}

