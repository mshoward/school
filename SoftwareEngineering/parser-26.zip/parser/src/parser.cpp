#include "parser-includes.hpp"

using namespace parser_sqli;
//demo



void main_init()
{
	if (mysql_library_init(0, NULL, NULL)) 
	{
		fprintf(stderr, "could not initialize MySQL library\n");
		std::cout << "could not initialize MySQL library" << std::endl;
		/** exit status 1 means the mysql library couldn't initialize */
		exit(1);
	}
	getConfiguration();
}

void main_exit()
{
	std::cout << "didn't segfault yet " << std::endl;
	mysql_library_end();
	//mysql_library_end();
}


void safe_NextPopFields(HoneyDLogStatement &someStmt, std::string &someString, std::fstream &someStream)
{
	
	if (!(someStream.eof()))
	{
		std::getline(someStream, someString);
		someStmt.populateFields(someString);
	}
}



int main()
{
	main_init();
	std::string bucket = "";
	std::fstream cache(configuration.cache_filePath.c_str(), std::ios_base::in);
	std::fstream honey_log(configuration.honeyd_log_filePath.c_str(), std::ios_base::in);
	//std::fstream apache_log(configuration.apache_log_filePath.c_str(), std::ios_base::in);
	
	HoneyDLogStatement coolGuyJones;
	
	unsigned long int lineNo = 0;
	unsigned long int last = 0;
	unsigned long int totalNo = 18762;
	//printf("HELLO WORLD!\n");
	mysqlPush mysql
	(
		"honeypot1.db.7456864.hostedresource.com",
		"honeypot1",
		"Honeypot1#",
		"honeypot1",
		3306,
		NULL,
		0,
		&cache
	);
	
	//flush any unsent queries
	flushCache(cache, mysql);
	cache.close();
	//dump data and reopen file
	dumpFile(configuration.cache_filePath);
	cache.open(configuration.cache_filePath.c_str(), std::ios_base::out);
	std::cout << "IT'S WORKING: " << mysql.isConnected() << std::endl;
	std::cout << last << " %" << std::endl;
	while (!(honey_log.eof()))
	{
		lineNo++;
		if (((lineNo * 100) / totalNo) != last)
		{
			last = ((lineNo * 100) / totalNo);
			std::cout << last << " %" << std::endl;
		}
		safe_NextPopFields(coolGuyJones, bucket, honey_log);
		mysql.update(&coolGuyJones);
	}
	honey_log.close();
	dumpFile(configuration.honeyd_log_filePath);
	
	/*while (!(apache_log.eof()))
	{
		safe_NextPopFields(coolGuyJones, bucket, apache_log);
		mysql.update(&coolGuyJones);
	}
	apache_log.close();
	dumpFile(configuration.apache_log_filePath);
	*/
	std::cout << "IT'S WORKING: " << mysql.isConnected() << std::endl;
	
	//int tempInt;
	//std::cin >> tempInt;
	
	//std::string buf;
	//int n;
	//std::cout << "hello world" << std::endl;
	/*for (int i = 0; i < SQLI_LIST_LENGTH; i++)
	{
		std::cout << SQLI_LIST[i] << std::endl;
	}
	*/
	//std::fstream f1("samples/logfile.txt", std::ios::in);
	//HoneyDLogStatement stmt;
	//hdparser::honeyd_parser par;
	//int counter = 0;
	//while (!(f1.eof()))
	//{
		//std::getline(f1, buf);
		//stmt.populateFields(buf);
		//par.setString(buf);
		//std::cout << " " << counter;// << std::endl;
		//std::cout << "ts:" << stmt.timeStamp << std::endl;
		//std::cout << "TSBool: " << par.isTimeStamp(stmt.timeStamp) << std::endl;
		//std::cout << "pt:" << stmt.packetType << std::endl;
		//std::cout << "PTBool: " << par.isPacketType(stmt.packetType) << std::endl;
		//std::cout << "sip:" << stmt.sourceIP << std::endl;
		//std::cout << "IPBool: " << par.isIP(stmt.sourceIP) << std::endl;
		//std::cout << "ss:" << stmt.sourceSocket << std::endl;
		//std::cout << "SBool: " << par.isSocket(stmt.sourceSocket) << std::endl;
		//std::cout << "tip:" << stmt.targetIP << std::endl;
		//std::cout << "IPBool: " << par.isIP(stmt.targetIP) << std::endl;
		//std::cout << "ts: " << stmt.targetSocket << std::endl;
		//std::cout << "SBool: " << par.isSocket(stmt.targetSocket) << std::endl;
		//std::cout << "osv:" << stmt.osVersion << std::endl;
		//std::cout << counter << std::endl;
		//counter++;
		//std::cin >> n;
	//}
	//std::cout << std::endl;
	
	//f1.close();
	//std::cout << "DONE" << std::endl;
	std::cout << std::endl;
	mysql.close();
	std::cout << "closed successfully?" << std::endl;
	mysql.clean();
	std::cout << "cleaned successfully?" << std::endl;
	main_exit();
	std::cout << "exited successfully?" << std::endl;
	std::cout << "DONE" << std::endl;
	/** exit status zero means everything is ok */
return 0;
}
