var annotated =
[
    [ "hdparser", "namespacehdparser.html", "namespacehdparser" ],
    [ "parser_sqli", "namespaceparser__sqli.html", null ],
    [ "HoneyDLogStatement", "class_honey_d_log_statement.html", "class_honey_d_log_statement" ],
    [ "mysqlPush", "classmysql_push.html", "classmysql_push" ],
    [ "s_configuration", "structs__configuration.html", "structs__configuration" ]
];