#include "../parser-includes.hpp"




void main_init()
{
	if (mysql_library_init(0, NULL, NULL)) 
	{
		fprintf(stderr, "could not initialize MySQL library\n");
		std::cout << "could not initialize MySQL library" << std::endl;
		/** exit status 1 means the mysql library couldn't initialize */
		exit(1);
	}
	getConfiguration();
}

void main_exit()
{
	std::cout << "didn't segfault yet " << std::endl;
	mysql_library_end();
	//mysql_library_end();
}




int main()
{
	main_init();
	char *s = "foo2";
	char *s2 = "bar2";
	mysqlPush mysql
	(
		"honeypot1.db.7456864.hostedresource.com",
		"honeypot1",
		"Honeypot1#",
		"honeypot1",
		3306,
		NULL,
		0,
		
	);
	MYSQL_BIND binds[2];
	memset(binds, 0, sizeof(binds));
	MYSL_STMT * stmt = mysql_stmt_init(mysql.mysql);
	mysql_stmt_prepare(stmt,
	"INSERT INTO 'honeypot1'.'testTable' ('col1','col2', 'col3') VALUES ( NULL, ?, ?)",
	81);
	
	mysql_stmt_close(stmt);
	main_exit();
}
